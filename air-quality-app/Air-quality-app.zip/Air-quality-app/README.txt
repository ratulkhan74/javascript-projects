You need to use your **own api key** to make this project work.

API website : https://www.iqair.com/

I explain how to create it at the beginning of the course.